start_epoch = 1
num_epochs = 5
batch_size = 256
optim_type = 'Adam'
resize=224
crop_size=224
lr=0.01
